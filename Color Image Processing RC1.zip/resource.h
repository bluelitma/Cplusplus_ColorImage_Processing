﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageAlpha1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageAlpha1TYPE        130
#define IDD_CONSTANT                    310
#define IDD_CONSTANT_0TO100             311
#define IDD_CONSTANT_0TO255             312
#define IDD_CONSTANT_0TO101             313
#define IDD_CONSTANT_0TO4               313
#define IDD_CONSTANT_0TO360             314
#define IDD_CONSTANT_ASKTWO             315
#define IDC_EDIT_CONSTANT               1000
#define IDC_EDIT_CONSTANT2              1001
#define ID_32771                        32771
#define ID                              32772
#define IDM_EQUAL_IMAGE                 32773
#define ID_32774                        32774
#define IDM_GRAY_SCALE                  32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define IDM_ADD_IMAGE                   32784
#define IDM_REVERSE_IMAGE               32785
#define IDM                             32786
#define IDM_BW_IMAGE                    32787
#define IDM_GAMMA_IMAGE                 32788
#define IDM_BINARY_IMAGE                32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_32798                        32798
#define ID_32799                        32799
#define ID_32800                        32800
#define ID_32801                        32801
#define ID_32802                        32802
#define ID_32803                        32803
#define ID_32804                        32804
#define ID_32805                        32805
#define ID_32806                        32806
#define ID_32807                        32807
#define ID_32808                        32808
#define ID_32809                        32809
#define IDM_CAP_PARA_IMAGE              32810
#define IDM_CUP_PARA_IMAGE              32811
#define IDM_ZOOM_OUT                    32812
#define IDM_ZOOM_IN_FORWARD             32813
#define IDM_ZOOM_IN_BACKWARD            32814
#define ID_32815                        32815
#define IDM_CHANGE_SATUR                32816
#define ID_32817                        32817
#define IDM_PICK_ORANGE                 32818
#define IDM_ROTATE                      32819
#define IDM_ROTATE_BACKWARD             32820
#define IDM_MOVE                        32821
#define IDM_LF_MIRROR                   32822
#define IDM_UD_MIRROR                   32823
#define IDM_STRECT                      32824
#define IDM_STRETCHING                  32825
#define IDM_END                         32826
#define IDM_END_IN                      32827
#define IDM_EQUALIZING                  32828
#define IDM_EMBOSS                      32829
#define IDM_BLUR                        32830
#define IDM_SHARPEN                     32831
#define IDM_EDGE1                       32832
#define IDM_EDGE2                       32833
#define IDM_EDGE3                       32834
#define IDM_EDGE4                       32835
#define ID_32836                        32836
#define IDM_EMBOSS_HSI                  32837
#define ID_32838                        32838
#define IDM_EDGE1_HSI                   32839

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32840
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
